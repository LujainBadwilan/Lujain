//CCCY312 Project1
//Wojood Alghamdi		#1912211
//Lujain Badwilan		#1905100
//Malak Mossad 			#1913695

#include <stdio.h>
#include <iostream>
#include <bits/stdc++.h>
using namespace std;

//this function is to convert hex to binary
string HexToBin(char hex[])
{
	char bin[65] = "";

	/* Extract first digit and find binary of each hex digit */
	for (int i = 0; hex[i] != '\0'; i++)
	{
		switch (hex[i])
		{
		case '0':
			strcat(bin, "0000");
			break;
		case '1':
			strcat(bin, "0001");
			break;
		case '2':
			strcat(bin, "0010");
			break;
		case '3':
			strcat(bin, "0011");
			break;
		case '4':
			strcat(bin, "0100");
			break;
		case '5':
			strcat(bin, "0101");
			break;
		case '6':
			strcat(bin, "0110");
			break;
		case '7':
			strcat(bin, "0111");
			break;
		case '8':
			strcat(bin, "1000");
			break;
		case '9':
			strcat(bin, "1001");
			break;
		case 'a':
		case 'A':
			strcat(bin, "1010");
			break;
		case 'b':
		case 'B':
			strcat(bin, "1011");
			break;
		case 'c':
		case 'C':
			strcat(bin, "1100");
			break;
		case 'd':
		case 'D':
			strcat(bin, "1101");
			break;
		case 'e':
		case 'E':
			strcat(bin, "1110");
			break;
		case 'f':
		case 'F':
			strcat(bin, "1111");
			break;
		default:
			cout << "Invalid hexadecimal input.";
		}
	}

	return bin;
}

//this function is to convert from Binary to hex
string bin2hex(string s)
{
	// binary to hexadecimal conversion
	unordered_map<string, string> mp;
	mp["0000"] = "0";
	mp["0001"] = "1";
	mp["0010"] = "2";
	mp["0011"] = "3";
	mp["0100"] = "4";
	mp["0101"] = "5";
	mp["0110"] = "6";
	mp["0111"] = "7";
	mp["1000"] = "8";
	mp["1001"] = "9";
	mp["1010"] = "A";
	mp["1011"] = "B";
	mp["1100"] = "C";
	mp["1101"] = "D";
	mp["1110"] = "E";
	mp["1111"] = "F";
	string hex = "";
	for (int i = 0; i < s.length(); i += 4)
	{
		string ch = "";
		ch += s[i];
		ch += s[i + 1];
		ch += s[i + 2];
		ch += s[i + 3];
		hex += mp[ch];
	}
	return hex;
}

//
string GetHexFromBin(string sBinary)
{
	string rest("0x"), tmp, chr = "0000";
	int len = sBinary.length() / 4;
	chr = chr.substr(0, len);
	sBinary = chr + sBinary;
	for (int i = 0; i < sBinary.length(); i += 4)
	{
		tmp = sBinary.substr(i, 4);
		if (!tmp.compare("0000"))
		{
			rest = rest + "0";
		}
		else if (!tmp.compare("0001"))
		{
			rest = rest + "1";
		}
		else if (!tmp.compare("0010"))
		{
			rest = rest + "2";
		}
		else if (!tmp.compare("0011"))
		{
			rest = rest + "3";
		}
		else if (!tmp.compare("0100"))
		{
			rest = rest + "4";
		}
		else if (!tmp.compare("0101"))
		{
			rest = rest + "5";
		}
		else if (!tmp.compare("0110"))
		{
			rest = rest + "6";
		}
		else if (!tmp.compare("0111"))
		{
			rest = rest + "7";
		}
		else if (!tmp.compare("1000"))
		{
			rest = rest + "8";
		}
		else if (!tmp.compare("1001"))
		{
			rest = rest + "9";
		}
		else if (!tmp.compare("1010"))
		{
			rest = rest + "A";
		}
		else if (!tmp.compare("1011"))
		{
			rest = rest + "B";
		}
		else if (!tmp.compare("1100"))
		{
			rest = rest + "C";
		}
		else if (!tmp.compare("1101"))
		{
			rest = rest + "D";
		}
		else if (!tmp.compare("1110"))
		{
			rest = rest + "E";
		}
		else if (!tmp.compare("1111"))
		{
			rest = rest + "F";
		}
		else
		{
			continue;
		}
	}
	return rest;
}

// Function to do a circular left shift by 2
string shift_left_twice(string leftSide)
{
	string shifted = "";
	for (int i = 0; i < 2; i++)
	{
		for (int j = 1; j < 32; j++)
		{
			shifted += leftSide[j];
		}
		shifted += leftSide[0];
		leftSide = shifted;
		shifted = "";
	}
	return leftSide;
}

// Function to do a circular right shift by 2
string shift_right_twice(string rightSide)
{
	string shifted = "";
	string b = "";
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 31; j++)
		{
			shifted += rightSide[j];
		}
		b += rightSide[31];
		rightSide = b + shifted;
		b = "";
		shifted = "";
	}
	return rightSide;
}

// Function to compute xor between two strings
string Xor(string a, string b)
{
	string result = "";
	int size = b.size();
	for (int i = 0; i < size; i++)
	{
		if (a[i] != b[i])
		{
			result += "1";
		}
		else
		{
			result += "0";
		}
	}
	return result;
}

//encryption algorthim function
string encryption(string pt, string encKey)
{
	//these are the encryption steps
	//permutation table
	//divide to left & right
	//shift left by 2
	//XOR with key (left side)
	//swap left and right
	//combine left and right
	//repat 14 times

	// The initial permutation table
	int initial_permutation[64] = {
		58, 50, 42, 34, 26, 18, 10, 2,
		60, 52, 44, 36, 28, 20, 12, 4,
		62, 54, 46, 38, 30, 22, 14, 6,
		64, 56, 48, 40, 32, 24, 16, 8,
		57, 49, 41, 33, 25, 17, 9, 1,
		59, 51, 43, 35, 27, 19, 11, 3,
		61, 53, 45, 37, 29, 21, 13, 5,
		63, 55, 47, 39, 31, 23, 15, 7};

	// The inverse permutation table
	int inverse_permutation[64] = {
		40, 8, 48, 16, 56, 24, 64, 32,
		39, 7, 47, 15, 55, 23, 63, 31,
		38, 6, 46, 14, 54, 22, 62, 30,
		37, 5, 45, 13, 53, 21, 61, 29,
		36, 4, 44, 12, 52, 20, 60, 28,
		35, 3, 43, 11, 51, 19, 59, 27,
		34, 2, 42, 10, 50, 18, 58, 26,
		33, 1, 41, 9, 49, 17, 57, 25};

	//1. Applying the initial permutation
	string perm = "";
	for (int i = 0; i < 64; i++)
	{
		perm += pt[initial_permutation[i] - 1];
	}

	// 2. Dividing the result into two equal halves
	string left = perm.substr(0, 32);
	string right = perm.substr(32, 32);

	// The plain text is encrypted 14 times
	for (int i = 0; i < 14; i++)
	{
		//sheft left by 2
		string leftShifted = "";
		leftShifted = shift_left_twice(left);

		// 3.3. The result is xored with a key
		string xored = Xor(encKey, leftShifted); //one key for all rounds, change right to left

		// 3.7. The left and the right parts of the plain text are swapped
		string temp = right;
		right = xored;
		left = temp;
	}

	string combined_text = left + right;

	string cipher = "";

	//The inverse of the initial permuttaion is applied
	for (int i = 0; i < 64; i++)
	{
		cipher += combined_text[inverse_permutation[i] - 1];
	}

	//And we finally get the cipher text
	return cipher;
}

//this is the decryption method
string decryption(string ct, string encKey)
{

	// The initial permutation table
	int initial_permutation[64] = {
		58, 50, 42, 34, 26, 18, 10, 2,
		60, 52, 44, 36, 28, 20, 12, 4,
		62, 54, 46, 38, 30, 22, 14, 6,
		64, 56, 48, 40, 32, 24, 16, 8,
		57, 49, 41, 33, 25, 17, 9, 1,
		59, 51, 43, 35, 27, 19, 11, 3,
		61, 53, 45, 37, 29, 21, 13, 5,
		63, 55, 47, 39, 31, 23, 15, 7};

	// The inverse permutation table
	int inverse_permutation[64] = {
		40, 8, 48, 16, 56, 24, 64, 32,
		39, 7, 47, 15, 55, 23, 63, 31,
		38, 6, 46, 14, 54, 22, 62, 30,
		37, 5, 45, 13, 53, 21, 61, 29,
		36, 4, 44, 12, 52, 20, 60, 28,
		35, 3, 43, 11, 51, 19, 59, 27,
		34, 2, 42, 10, 50, 18, 58, 26,
		33, 1, 41, 9, 49, 17, 57, 25};

	//1. Applying the initial permutation
	string perm = "";
	for (int i = 0; i < 64; i++)
	{
		perm += ct[initial_permutation[i] - 1];
	}

	// 2. Dividing the result into two equal halves
	string left = perm.substr(0, 32);
	string right = perm.substr(32, 32);

	for (int i = 0; i < 14; i++)
	{
		string xored = Xor(encKey, right); //one key for all rounds, change right to left

		//sheft right by 2
		string rightShifted = "";
		rightShifted = shift_right_twice(xored);

		// 3.7. The left and the right parts of the plain text are swapped

		string temp = left;
		left = rightShifted;
		right = temp;
	}

	string combined_text = left + right;

	string plain = "";

	//The inverse of the initial permuttaion is applied
	for (int i = 0; i < 64; i++)
	{
		plain += combined_text[inverse_permutation[i] - 1];
	}

	//And we finally get the plain text
	return plain;
}

int main()
{ //intilais vairiables
	string cipher = "";
	string decrypt = "";
	string cipherinHex = "";
	string plaininHex = "";
	char bruteForcekey[9];
	string bruteForceDecrypted = "";
	string bruteForcekeyHTB = "";

	string sepre = "\n---------------------------------------------------\n";
	cout << sepre << "WELCOME to Wojood | Malak | Lujain | Algorithm" << sepre;

	string keyHTB = "";
	string plainTextHTB = "";

	//initialize array to take key from user (16 char)
	char key[9];
	cout << "Enter your key (8 digit in HEXA): ";
	cin >> key;

	//call for key
	keyHTB = HexToBin(key);
	cout << keyHTB;

	//initialize array to take key from user
	char plainText[17]; //strings array
	cout << "\nEnter desired text to encrypt (16 digit in HEXA): ";
	cin >> plainText;

	//call for text
	plainTextHTB = HexToBin(plainText);
	cout << plainTextHTB;

	cipher = encryption(plainTextHTB, keyHTB);
	cipherinHex = bin2hex(cipher);
	//printing the cipher text
	cout << "\nCiphertext is = " << cipherinHex << sepre;

	cout << "Do you want to decrypt the message?(1 for YES or 2 for NO): ";
	int choice;
	cin >> choice;
	bool ch = true;
	do
	{
		switch (choice)
		{
		case 1:
			// call encryption
			cout << sepre;
			cout << "\nDecryption\n";
			decrypt = decryption(cipher, keyHTB);
			plaininHex = bin2hex(decrypt);
			cout << "\n\nThis is the decrypted text: " << plaininHex;
			ch = false;
			break;

		case 2:
			cout << sepre << "                    THANK YOU          " << sepre;
			ch = false;
			return (0);
			
			break;

		default:
			cout << "\nWrong choice! please enter 1 or 2";
			cout << "Do you want to decrypt the message?(1 for YES or 2 for NO)";
			cin >> choice;
			ch = false;
		}

	} while (ch);

	// we used kali crunch tool to generate a file that contain all the possible keys
	//list of possiable keys
	cout << "\n\n\n\n\n";
	string keys[505] = {
		"01234567",
		"000bfe50",
		"000bfe51",
		"000bfe52",
		"000bfe53",
		"000bfe54",
		"000bfe55",
		"000bfe56",
		"000bfe57",
		"000bfe58",
		"000bfe59",
		"000bfe5a",
		"000bfe5b",
		"000bfe5c",
		"000bfe5d",
		"000bfe5e",
		"000bfe5f",
		"000bfe60",
		"000bfe61",
		"000bfe62",
		"000bfe63",
		"000bfe64",
		"000bfe65",
		"000bfe66",
		"000bfe67",
		"000bfe68",
		"000bfe69",
		"000bfe6a",
		"000bfe6b",
		"000bfe6c",
		"000bfe6d",
		"000bfe6e",
		"000bfe6f",
		"000bfe70",
		"000bfe71",
		"000bfe72",
		"000bfe73",
		"000bfe74",
		"000bfe75",
		"000bfe76",
		"000bfe77",
		"000bfe78",
		"000bfe79",
		"000bfe7a",
		"000bfe7b",
		"000bfe7c",
		"000bfe7d",
		"000bfe7e",
		"000bfe7f",
		"000bfe80",
		"000bfe81",
		"000bfe82",
		"000bfe83",
		"000bfe84",
		"000bfe85",
		"000bfe86",
		"000bfe87",
		"000bfe88",
		"000bfe89",
		"000bfe8a",
		"000bfe8b",
		"000bfe8c",
		"000bfe8d",
		"000bfe8e",
		"000bfe8f",
		"000bfe90",
		"000bfe91",
		"000bfe92",
		"000bfe93",
		"000bfe94",
		"000bfe95",
		"000bfe96",
		"000bfe97",
		"000bfe98",
		"000bfe99",
		"000bfe9a",
		"000bfe9b",
		"000bfe9c",
		"000bfe9d",
		"000bfe9e",
		"000bfe9f",
		"000bfea0",
		"000bfea1",
		"000bfea2",
		"000bfea3",
		"000bfea4",
		"000bfea5",
		"000bfea6",
		"000bfea7",
		"000bfea8",
		"000bfea9",
		"000bfeaa",
		"000bfeab",
		"000bfeac",
		"000bfead",
		"000bfeae",
		"000bfeaf",
		"000bfeb0",
		"000bfeb1",
		"000bfeb2",
		"000bfeb3",
		"000bfeb4",
		"000bfeb5",
		"000bfeb6",
		"000bfeb7",
		"000bfeb8",
		"000bfeb9",
		"000bfeba",
		"000bfebb",
		"000bfebc",
		"000bfebd",
		"000bfebe",
		"000bfebf",
		"000bfec0",
		"000bfec1",
		"000bfec2",
		"000bfec3",
		"000bfec4",
		"000bfec5",
		"000bfec6",
		"000bfec7",
		"000bfec8",
		"000bfec9",
		"000bfeca",
		"000bfecb",
		"000bfecc",
		"000bfecd",
		"000bfece",
		"000bfecf",
		"000bfed0",
		"000bfed1",
		"000bfed2",
		"000bfed3",
		"000bfed4",
		"000bfed5",
		"000bfed6",
		"000bfed7",
		"000bfed8",
		"000bfed9",
		"000bfeda",
		"000bfedb",
		"000bfedc",
		"000bfedd",
		"000bfede",
		"000bfedf",
		"000bfee0",
		"000bfee1",
		"000bfee2",
		"000bfee3",
		"000bfee4",
		"000bfee5",
		"000bfee6",
		"000bfee7",
		"000bfee8",
		"000bfee9",
		"000bfeea",
		"000bfeeb",
		"000bfeec",
		"000bfeed",
		"000bfeee",
		"000bfeef",
		"000bfef0",
		"000bfef1",
		"000bfef2",
		"000bfef3",
		"000bfef4",
		"000bfef5",
		"000bfef6",
		"000bfef7",
		"000bfef8",
		"000bfef9",
		"000bfefa",
		"000bfefb",
		"000bfefc",
		"000bfefd",
		"000bfefe",
		"000bfeff",
		"000bff00",
		"000bff01",
		"000bff02",
		"000bff03",
		"000bff04",
		"000bff05",
		"000bff06",
		"000bff07",
		"000bff08",
		"000bff09",
		"000bff0a",
		"000bff0b",
		"000bff0c",
		"000bff0d",
		"000bff0e",
		"000bff0f",
		"000bff10",
		"000bff11",
		"000bff12",
		"000bff13",
		"000bff14",
		"000bff15",
		"000bff16",
		"000bff17",
		"000bff18",
		"000bff19",
		"000bff1a",
		"000bff1b",
		"000bff1c",
		"000bff1d",
		"000bff1e",
		"000bff1f",
		"000bff20",
		"000bff21",
		"000bff22",
		"000bff23",
		"000bff24",
		"000bff25",
		"000bff26",
		"000bff27",
		"000bff28",
		"000bff29",
		"000bff2a",
		"000bff2b",
		"000bff2c",
		"000bff2d",
		"000bff2e",
		"000bff2f",
		"000bff30",
		"000bff31",
		"000bff32",
		"000bff33",
		"000bff34",
		"000bff35",
		"000bff36",
		"000bff37",
		"000bff38",
		"000bff39",
		"000bff3a",
		"000bff3b",
		"000bff3c",
		"000bff3d",
		"000bff3e",
		"000bff3f",
		"000bff40",
		"000bff41",
		"000bff42",
		"000bff43",
		"000bff44",
		"000bff45",
		"000bff46",
		"000bff47",
		"000bff48",
		"000bff49",
		"000bff4a",
		"000bff4b",
		"000bff4c",
		"000bff4d",
		"000bff4e",
		"000bff4f",
		"000bff50",
		"000bff51",
		"000bff52",
		"000bff53",
		"000bff54",
		"000bff55",
		"000bff56",
		"000bff57",
		"000bff58",
		"000bff59",
		"000bff5a",
		"000bff5b",
		"000bff5c",
		"000bff5d",
		"000bff5e",
		"000bff5f",
		"000bff60",
		"000bff61",
		"000bff62",
		"000bff63",
		"000bff64",
		"000bff65",
		"000bff66",
		"000bff67",
		"000bff68",
		"000bff69",
		"000bff6a",
		"000bff6b",
		"000bff6c",
		"000bff6d",
		"000bff6e",
		"000bff6f",
		"000bff70",
		"000bff71",
		"000bff72",
		"000bff73",
		"000bff74",
		"000bff75",
		"000bff76",
		"000bff77",
		"000bff78",
		"000bff79",
		"000bff7a",
		"000bff7b",
		"000bff7c",
		"000bff7d",
		"000bff7e",
		"000bff7f",
		"000bff80",
		"000bff81",
		"000bff82",
		"000bff83",
		"000bff84",
		"000bff85",
		"000bff86",
		"000bff87",
		"000bff88",
		"000bff89",
		"000bff8a",
		"000bff8b",
		"000bff8c",
		"000bff8d",
		"000bff8e",
		"000bff8f",
		"000bff90",
		"000bff91",
		"000bff92",
		"000bff93",
		"000bff94",
		"000bff95",
		"000bff96",
		"000bff97",
		"000bff98",
		"000bff99",
		"000bff9a",
		"000bff9b",
		"000bff9c",
		"000bff9d",
		"000bff9e",
		"000bff9f",
		"000bffa0",
		"000bffa1",
		"000bffa2",
		"000bffa3",
		"000bffa4",
		"000bffa5",
		"000bffa6",
		"000bffa7",
		"000bffa8",
		"000bffa9",
		"000bffaa",
		"000bffab",
		"000bffac",
		"000bffad",
		"000bffae",
		"000bffaf",
		"000bffb0",
		"000bffb1",
		"000bffb2",
		"000bffb3",
		"000bffb4",
		"000bffb5",
		"000bffb6",
		"000bffb7",
		"000bffb8",
		"000bffb9",
		"000bffba",
		"000bffbb",
		"000bffbc",
		"000bffbd",
		"000bffbe",
		"000bffbf",
		"000bffc0",
		"000bffc1",
		"000bffc2",
		"000bffc3",
		"000bffc4",
		"000bffc5",
		"000bffc6",
		"000bffc7",
		"000bffc8",
		"000bffc9",
		"000bffca",
		"000bffcb",
		"000bffcc",
		"000bffcd",
		"000bffce",
		"000bffcf",
		"000bffd0",
		"000bffd1",
		"000bffd2",
		"000bffd3",
		"000bffd4",
		"000bffd5",
		"000bffd6",
		"000bffd7",
		"000bffd8",
		"000bffd9",
		"000bffda",
		"000bffdb",
		"000bffdc",
		"000bffdd",
		"000bffde",
		"000bffdf",
		"000bffe0",
		"000bffe1",
		"000bffe2",
		"000bffe3",
		"000bffe4",
		"000bffe5",
		"000bffe6",
		"000bffe7",
		"000bffe8",
		"000bffe9",
		"000bffea",
		"000bffeb",
		"000bffec",
		"000bffed",
		"000bffee",
		"000bffef",
		"000bfff0",
		"000bfff1",
		"000bfff2",
		"000bfff3",
		"000bfff4",
		"000bfff5",
		"000bfff6",
		"000bfff7",
		"000bfff8",
		"000bfff9",
		"000bfffa",
		"000bfffb",
		"000bfffc",
		"000bfffd",
		"000bfffe",
		"000bffff",
		"000c0000",
		"000c0001",
		"000c0002",
		"000c0003",
		"000c0004",
		"000c0005",
		"000c0006",
		"000c0007",
		"000c0008",
		"000c0009",
		"000c000a",
		"000c000b",
		"000c000c",
		"000c000d",
		"000c000e",
		"000c000f",
		"000c0010",
		"000c0011",
		"000c0012",
		"000c0013",
		"000c0014",
		"000c0015",
		"000c0016",
		"000c0017",
		"000c0018",
		"000c0019",
		"000c001a",
		"000c001b",
		"000c001c",
		"000c001d",
		"000c001e",
		"000c001f",
		"000c0020",
		"000c0021",
		"000c0022",
		"000c0023",
		"000c0024",
		"000c0025",
		"000c0026",
		"000c0027",
		"000c0028",
		"000c0029",
		"000c002a",
		"000c002b",
		"000c002c",
		"000c002d",
		"000c002e",
		"000c002f",
		"000c0030",
		"000c0031",
		"000c0032",
		"000c0033",
		"000c0034",
		"000c0035",
		"000c0036",
		"000c0037",
		"000c0038",
		"000c0039",
		"000c003a",
		"000c003b",
		"000c003c",
		"000c003d",
		"000c003e",
		"000c003f",
		"000c0040",
		"000c0041",
		"000c0042",
		"000c0043"};
	//we want to store each index in a bruteForcekey so we can try ro decrypt using it
	int arrSize = sizeof(keys) / sizeof(keys[0]);

	for (int i = 0; i < arrSize; i++)
	{
		string keysArrIndex = keys[i];
		//making a copy of keysArrIndex
		strcpy(bruteForcekey, keysArrIndex.c_str());
		bruteForcekeyHTB = HexToBin(bruteForcekey);
		//call decryption method so we can test it
		bruteForceDecrypted = decryption(cipher, bruteForcekeyHTB);
		//compare the result with the original plain text
		if (decrypt.compare(bruteForceDecrypted) == 0)
		{
			cout << "\n\n succeed key number = " << i << "\n\n";
			return 0;
		}
	}
	if (decrypt.compare(bruteForceDecrypted) != 0)
	{
		cout << "\n\n key number is not found in this list \n\n";
	}

	return 0;
}